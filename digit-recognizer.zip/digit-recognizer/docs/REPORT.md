# Handwritten Digit Recognizer — Project Report
**Subject:** Open Source Tool Framework

## 1. Aim
Build a small web app where a user draws a digit (0–9) and a CNN predicts it, using only open source tools.

## 2. Open Source Tools Used

| Tool | Role | License |
|------|------|---------|
| PyTorch | Build and train the CNN | BSD-style |
| torchvision | Download MNIST, augmentation | BSD |
| OpenCV | Image preprocessing | Apache 2.0 |
| Gradio | Web UI with drawing canvas | Apache 2.0 |
| NumPy | Array handling | BSD |
| pytest | Testing | MIT |
| Python | Language | PSF |

## 3. Definitions
- **MNIST:** 70,000 grayscale 28x28 images of handwritten digits (60k train, 10k test).
- **CNN:** Neural network that uses convolution filters to learn spatial features from images.
- **Convolution:** Sliding a small filter over an image to detect edges and shapes.
- **ReLU:** Activation `max(0, x)`; adds non-linearity.
- **Max Pooling:** Keeps the strongest value in each window; reduces size.
- **Dropout:** Randomly switches off neurons during training to reduce overfitting.
- **Softmax:** Converts 10 raw scores into probabilities that sum to 1.
- **Data Augmentation:** Small random shifts, rotations, and scaling of training images.

## 4. Architecture

```
Input 1x28x28 -> Conv(32,3x3)+ReLU -> Conv(64,3x3)+ReLU -> MaxPool(2) -> Dropout(0.25)
              -> Flatten(9216) -> Dense(128)+ReLU -> Dropout(0.5) -> Dense(10) -> Softmax
```

## 5. Workflow
1. `train.py` loads MNIST, applies augmentation, trains with Adam + cross-entropy.
2. Weights are saved to `models/digit_cnn.pt`.
3. `app.py` loads weights and shows a Gradio sketch canvas.
4. Drawing → `preprocess.py` (OpenCV) → model → top-3 probabilities shown live.

## 6. Why Preprocessing Matters
MNIST digits are white on black, fitted in a 20x20 box, centred by centre of mass. A raw canvas drawing differs, so OpenCV does: grayscale → invert if needed → blur → threshold → bounding box crop → resize → centre → normalize. Without this, accuracy on drawn digits drops sharply.

## 7. Comparison: Keras vs PyTorch

| Point | PyTorch | TensorFlow/Keras |
|-------|---------|------------------|
| Style | Pythonic, explicit training loop | High-level `model.fit()` |
| Debugging | Easy (dynamic graphs) | Easier now, was harder in TF1 |
| Backed by | Meta / Linux Foundation | Google |
| Best for | Research, flexibility | Quick prototypes, deployment tooling |

## 8. Possible Extensions
- Add a confusion matrix plot after training.
- Compare with scikit-learn SVM on the same data.
- Deploy free on Hugging Face Spaces.

## 9. MCQs
1. Image size in MNIST? **a) 28x28** b) 32x32 c) 64x64 d) 224x224
2. Which library does preprocessing here? a) Gradio b) **OpenCV** c) pytest d) NumPy
3. Softmax outputs? a) Pixels b) Weights c) **Probabilities** d) Filters
4. Dropout helps to reduce? a) Speed b) **Overfitting** c) Accuracy d) Data size
5. Gradio is used for? a) Training b) Testing c) **Web UI** d) Data cleaning
6. Which loss suits 10-class classification? a) MSE b) **Cross-entropy** c) Hinge only d) L1

## 10. Viva Q&A
- **Why a CNN and not a plain neural network?** It exploits spatial structure and needs fewer parameters.
- **Why centre and resize the drawing?** To match how MNIST digits were prepared.
- **Why augmentation?** Hand-drawn digits vary in position, size, and tilt.
- **Why open source?** Free to use, inspect, modify, and backed by large communities.
- **Which optimizer?** Adam, adaptive learning rate, fast convergence.
- **How is accuracy measured?** Correct predictions on the 10k MNIST test set.
- **What if the canvas is blank?** Preprocessing returns `None` and no prediction is shown.
