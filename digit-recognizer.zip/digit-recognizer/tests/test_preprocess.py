import cv2, numpy as np
from preprocess import to_mnist_array, to_tensor_input


def _drawing(bg=255, ink=0):
    img = np.full((300, 300), bg, np.uint8)
    cv2.putText(img, "7", (80, 240), cv2.FONT_HERSHEY_SIMPLEX, 7, ink, 14)
    return img


def test_shape_and_range():
    out = to_mnist_array(_drawing())
    assert out.shape == (28, 28) and 0 <= out.min() and out.max() <= 1


def test_inversion_matches():
    a = to_mnist_array(_drawing(255, 0))
    b = to_mnist_array(_drawing(0, 255))
    assert np.abs(a - b).mean() < 0.05


def test_digit_is_centred():
    out = to_mnist_array(_drawing())
    ys, xs = np.nonzero(out > 0.1)
    assert 8 <= xs.mean() <= 20 and 8 <= ys.mean() <= 20


def test_blank_returns_none():
    assert to_mnist_array(np.full((200, 200), 255, np.uint8)) is None


def test_tensor_shape():
    assert to_tensor_input(to_mnist_array(_drawing())).shape == (1, 1, 28, 28)
