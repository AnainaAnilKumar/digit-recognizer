"""Gradio web demo.   Usage: python app.py   (train first)"""
import os
import gradio as gr
import numpy as np
import torch
from model import DigitCNN
from preprocess import to_mnist_array, to_tensor_input

WEIGHTS = "models/digit_cnn.pt"
if not os.path.exists(WEIGHTS):
    raise SystemExit("Model not found. Run:  python train.py")

net = DigitCNN()
net.load_state_dict(torch.load(WEIGHTS, map_location="cpu"))
net.eval()


def predict(sketch):
    if sketch is None:
        return None
    img = sketch["composite"] if isinstance(sketch, dict) else sketch
    if img is None:
        return None
    arr = to_mnist_array(np.array(img))
    if arr is None:
        return None  # blank canvas
    with torch.no_grad():
        probs = torch.softmax(net(torch.from_numpy(to_tensor_input(arr))), 1)[0]
    return {str(i): float(p) for i, p in enumerate(probs)}


demo = gr.Interface(
    fn=predict,
    inputs=gr.Sketchpad(label="Draw a digit (0-9)", type="numpy",
                        brush=gr.Brush(default_size=18, colors=["#000000"], color_mode="fixed")),
    outputs=gr.Label(num_top_classes=3, label="Prediction"),
    live=True,
    title="Handwritten Digit Recognizer",
    description="CNN (PyTorch) + OpenCV preprocessing + Gradio. Draw a digit, centred and large.",
)

if __name__ == "__main__":
    demo.launch()
