# Handwritten Digit Recognizer

Draw a digit in the browser and a CNN predicts it.
**Stack:** PyTorch (model) · OpenCV (preprocessing) · Gradio (web UI) · pytest (tests)

## Run

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python train.py --epochs 5      # downloads MNIST, saves models/digit_cnn.pt (~99% accuracy)
python app.py                   # open http://127.0.0.1:7860
python -m pytest tests -q       # optional: test preprocessing
```

## Structure

| File | Purpose |
|------|---------|
| `model.py` | CNN definition (2 conv + pool + 2 dense) |
| `preprocess.py` | OpenCV: invert, threshold, crop, resize to 20x20, centre in 28x28 |
| `train.py` | Training + evaluation on MNIST |
| `app.py` | Gradio Sketchpad demo with live prediction |
| `tests/` | Unit tests for preprocessing |
| `docs/REPORT.md` | Theory, tools table, MCQs, viva Q&A |

## Tips for good predictions
Draw one thick digit, large and roughly centred. Preprocessing handles the rest.
