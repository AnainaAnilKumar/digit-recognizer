"""OpenCV preprocessing: turn a user drawing into an MNIST-style 28x28 input.

MNIST digits are white on black, scaled to fit a 20x20 box and centred
by centre-of-mass inside 28x28. Matching this is what makes the demo accurate.
"""
import cv2
import numpy as np

MEAN, STD = 0.1307, 0.3081  # MNIST statistics


def to_gray(img: np.ndarray) -> np.ndarray:
    """Accept RGB / RGBA / gray arrays and return uint8 gray."""
    if img.ndim == 3:
        if img.shape[2] == 4:  # flatten alpha onto white
            a = img[..., 3:4] / 255.0
            img = (img[..., :3] * a + 255 * (1 - a)).astype(np.uint8)
        img = cv2.cvtColor(img.astype(np.uint8), cv2.COLOR_RGB2GRAY)
    return img.astype(np.uint8)


def to_mnist_array(img: np.ndarray):
    """Return a 28x28 float array in [0,1] (white digit on black), or None if blank."""
    g = to_gray(img)
    if np.median(g) > 127:          # dark ink on light paper -> invert
        g = 255 - g
    g = cv2.GaussianBlur(g, (3, 3), 0)
    _, mask = cv2.threshold(g, 30, 255, cv2.THRESH_BINARY)
    if cv2.countNonZero(mask) < 20:
        return None

    x, y, w, h = cv2.boundingRect(mask)
    digit = g[y:y + h, x:x + w]

    scale = 20.0 / max(w, h)
    digit = cv2.resize(digit, (max(1, round(w * scale)), max(1, round(h * scale))),
                       interpolation=cv2.INTER_AREA)

    canvas = np.zeros((28, 28), np.uint8)
    h2, w2 = digit.shape
    canvas[(28 - h2) // 2:(28 - h2) // 2 + h2, (28 - w2) // 2:(28 - w2) // 2 + w2] = digit

    # shift so centre of mass sits at (14, 14)
    m = cv2.moments(canvas)
    if m["m00"] > 0:
        cx, cy = m["m10"] / m["m00"], m["m01"] / m["m00"]
        M = np.float32([[1, 0, 14 - cx], [0, 1, 14 - cy]])
        canvas = cv2.warpAffine(canvas, M, (28, 28))
    return canvas.astype(np.float32) / 255.0


def to_tensor_input(arr: np.ndarray) -> np.ndarray:
    """Normalise to shape (1, 1, 28, 28) for the model."""
    return ((arr - MEAN) / STD).reshape(1, 1, 28, 28).astype(np.float32)
