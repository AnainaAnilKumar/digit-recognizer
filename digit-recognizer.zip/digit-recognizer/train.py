"""Train the CNN on MNIST.   Usage: python train.py --epochs 5"""
import argparse, json
import torch, torch.nn as nn
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
from model import DigitCNN
from preprocess import MEAN, STD


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--epochs", type=int, default=5)
    p.add_argument("--batch", type=int, default=128)
    p.add_argument("--lr", type=float, default=1e-3)
    a = p.parse_args()

    dev = "cuda" if torch.cuda.is_available() else "cpu"
    norm = transforms.Normalize((MEAN,), (STD,))
    train_tf = transforms.Compose([
        transforms.RandomAffine(10, translate=(0.1, 0.1), scale=(0.9, 1.1)),
        transforms.ToTensor(), norm])  # augmentation helps with hand-drawn input
    test_tf = transforms.Compose([transforms.ToTensor(), norm])

    train = DataLoader(datasets.MNIST("data", True, download=True, transform=train_tf),
                       batch_size=a.batch, shuffle=True)
    test = DataLoader(datasets.MNIST("data", False, download=True, transform=test_tf),
                      batch_size=1000)

    net, loss_fn = DigitCNN().to(dev), nn.CrossEntropyLoss()
    opt = torch.optim.Adam(net.parameters(), lr=a.lr)

    acc = 0.0
    for ep in range(1, a.epochs + 1):
        net.train()
        for x, y in train:
            x, y = x.to(dev), y.to(dev)
            opt.zero_grad()
            loss_fn(net(x), y).backward()
            opt.step()

        net.eval(); correct = 0
        with torch.no_grad():
            for x, y in test:
                correct += (net(x.to(dev)).argmax(1).cpu() == y).sum().item()
        acc = correct / len(test.dataset)
        print(f"epoch {ep}/{a.epochs}  test accuracy: {acc:.4f}")

    torch.save(net.state_dict(), "models/digit_cnn.pt")
    json.dump({"test_accuracy": acc, "epochs": a.epochs}, open("models/metrics.json", "w"))
    print("saved models/digit_cnn.pt")


if __name__ == "__main__":
    main()
